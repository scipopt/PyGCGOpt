#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def read_instance(filename):
    """ Method to read the .cpmp instances
    :param filename: path to the instance to read

    Format of the .cpmp instances:
    
    [nlocations] [nclusters]
    [distance_1_1] ... [distance_1_nlocations]
    [distance_2_1] ... [distance_2_nlocations]
    ...            ... ... 
    [distance_nlocations_1] ... [distance_nlocations_nlocations]
    [demand_1] ... [demand_nlocations]
    [capacity_1] ... [capacity_nlocations]
    """
    def is_integer(s):
        try:
            int(s)
            return True
        except ValueError:
            return False

    def _parse_line(fp, ncols):
        line = fp.readline()
        sp = line.split()
        assert len(sp) == ncols
        assert all(is_integer(s) for s in sp)
        return dict(enumerate([int(s) for s in sp], start=1))

    with open(filename) as fp:
        line = fp.readline()
        
        # Reading the first line separately to get nlocations and nclusters
        nlocations = 0
        nclusters = 0
        sp = line.split()
        if len(sp) > 0 and sp[0].isnumeric():
            assert len(sp) == 2
            assert is_integer(sp[0]) and is_integer(sp[1])
            nlocations = int(sp[0])
            nclusters = int(sp[1])
        
        # Reading the distance matrix
        distances = {}
        
        for i in range(1, nlocations + 1):
            distances[i] = _parse_line(fp, nlocations)
            
        # Reading the demands
        demands = _parse_line(fp, nlocations)
          
        # Reading the capacities
        capacities = _parse_line(fp, nlocations)
        
        
    return nlocations, nclusters, distances, demands, capacities
